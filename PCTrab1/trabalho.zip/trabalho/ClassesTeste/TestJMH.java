package ClassesTeste;

import org.openjdk.jmh.Main;
import org.openjdk.jmh.runner.RunnerException;

import java.io.IOException;

public class TestJMH {
    public static void main(String[] args) throws
            RunnerException, IOException {
        Main.main(args);
    }
}